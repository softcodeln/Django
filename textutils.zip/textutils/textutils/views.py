# This file is created by lucky.
from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

def about(request):
    purpose = 'About Us'
    info = 'My name is Laxmi Narayan Choudhary, I have started learning Django and it is going well till now.I will make it  a excellent and worthy skill for me.'
    para = {'purpose': purpose, 'info': info}
    return render(request, 'about.html',para)

def contact(request):
    purpose = 'Contact Us'
    info = 'Email : luckychoudhary821998@gmail.com'
    para = {'purpose': purpose, 'info': info}
    return render(request, 'about.html',para)

def analyzer(request):
    djtext              =       request.POST.get('text', 'default')

    removepunc          =       request.POST.get('removepunc','off')
    charcount           =       request.POST.get('charcount', 'off')
    uppercase           =       request.POST.get('UpperCase','off')
    new_LineRemover     =       request.POST.get('newLineRemover','off')
    extraSpacetruncate  =       request.POST.get('ExtraSpaceRemover','off')

    if removepunc=='off' and charcount=='off' and uppercase=='off' and new_LineRemover=='off' and extraSpacetruncate=='off':
        para = {'purpose': '', 'analyzed_text': 'Error'}
        return render(request, 'analyze.html', para)

    analyzedText = ''
    purpose = ''

    if removepunc == 'on':
        punctuation = '''!"#$%&'()*+, -./:;<=>?@[\]^_`{|}~'''
        for char in djtext:
            if char not in punctuation:
                analyzedText = analyzedText+char
        djtext = analyzedText
        analyzedText = ''
        purpose = purpose+' Removed punctuations'

    if uppercase == 'on':
        for char in djtext:
                analyzedText = analyzedText+char.upper()
        djtext = analyzedText
        analyzedText = ''
        purpose = purpose +' Converted to upper case'


    if new_LineRemover == 'on':
        for char in djtext:
            if char != '\n' and char != '\r':
                analyzedText = analyzedText+char
        djtext = analyzedText
        analyzedText = ''
        purpose = purpose +' Removed new line'

    if extraSpacetruncate == 'on':
        sz = len(djtext)
        for i in range(0, sz-1):
            if  not(djtext[i] == ' ' and djtext[i+1] == ' '):
                analyzedText = analyzedText+djtext[i]
        if  djtext[i+1] != ' ':
            analyzedText = analyzedText + djtext[i+1]
        djtext = analyzedText
        purpose = purpose+' Extra space removed'
        para = {'purpose': purpose, 'analyzed_text': djtext}
        return render(request, 'analyze.html', para)

    elif charcount == 'on':
        count = 0
        for char in djtext:
            count = count+1
        para = {'purpose': 'Character Count', 'analyzed_text': count}
        return render(request, 'analyze.html', para)

    else :
        para = {'purpose': purpose, 'analyzed_text': djtext}
        return render(request, 'analyze.html', para)